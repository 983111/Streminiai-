import 'package:flutter/material.dart';

class AppSeetings extends StatelessWidget {
  const AppSeetings({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SafeArea(
        child: const Column(
          children: [
            
          ],
        ),
      ),
    );
  }
}